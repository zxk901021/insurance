Library Project including compatibility ActionBar.

This can be used by an Android project to provide
access to ActionBar on applications running on API 7+.

There is technically no source, but the src folder is necessary
to ensure that the build system works.  The content is actually
located in libs/android-support-v7-appcompat.jar.
The accompanying resources must also be included in the application.

