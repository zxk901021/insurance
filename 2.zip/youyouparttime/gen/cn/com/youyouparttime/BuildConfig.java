/** Automatically generated file. DO NOT MODIFY */
package cn.com.youyouparttime;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}