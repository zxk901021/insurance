package cn.com.youyouparttime.entity;

public class CompanyInfo {

	private String comName;
	private String chargePerson;
	private String phone;
	private String email;
	private String address;
	private String comIntro;

	public CompanyInfo() {
	}

	public String getComName() {
		return comName;
	}

	public void setComName(String comName) {
		this.comName = comName;
	}

	public String getChargePerson() {
		return chargePerson;
	}

	public void setChargePerson(String chargePerson) {
		this.chargePerson = chargePerson;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getComIntro() {
		return comIntro;
	}

	public void setComIntro(String comIntro) {
		this.comIntro = comIntro;
	}

}
