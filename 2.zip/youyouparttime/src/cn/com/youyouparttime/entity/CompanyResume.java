package cn.com.youyouparttime.entity;

public class CompanyResume {

	private String jobType;
	private String jobTitle;
	private String jobTime;
	private String jobStatus;
	private String jobResumeCounts;
	private String jobId;

	public CompanyResume() {
		super();
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobTime() {
		return jobTime;
	}

	public void setJobTime(String jobTime) {
		this.jobTime = jobTime;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getJobResumeCounts() {
		return jobResumeCounts;
	}

	public void setJobResumeCounts(String jobResumeCounts) {
		this.jobResumeCounts = jobResumeCounts;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	
	
}
