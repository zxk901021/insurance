package cn.com.youyouparttime.entity;


public class PersonCenter {
	
	private int logo;
	private String text;
	private int btn;
	public int getLogo() {
		return logo;
	}
	public void setLogo(int logo) {
		this.logo = logo;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getBtn() {
		return btn;
	}
	public void setBtn(int btn) {
		this.btn = btn;
	}
	
	
}
