package cn.com.youyouparttime.entity;

public class StudentResumeInfo {

	private String imgUrl;
	private String time;
	private String jobIntent;
	private String name;
	private String sex;
	private String birthday;
	private String height;
	private String city;
	private String school;
	private String email;
	private String qq;
	private String phone;
	private String intro;
	private String exprience;
	private String timeId;
	private String intentId;
	private String cityId;
	private String specitly;
	private String healthkey;

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getJobIntent() {
		return jobIntent;
	}

	public void setJobIntent(String jobIntent) {
		this.jobIntent = jobIntent;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public String getExprience() {
		return exprience;
	}

	public void setExprience(String exprience) {
		this.exprience = exprience;
	}

	public StudentResumeInfo() {
	}

	public String getTimeId() {
		return timeId;
	}

	public void setTimeId(String timeId) {
		this.timeId = timeId;
	}

	public String getIntentId() {
		return intentId;
	}

	public void setIntentId(String intentId) {
		this.intentId = intentId;
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public String getSpecitly() {
		return specitly;
	}

	public void setSpecitly(String specitly) {
		this.specitly = specitly;
	}

	public String getHealthkey() {
		return healthkey;
	}

	public void setHealthkey(String healthkey) {
		this.healthkey = healthkey;
	}

	
}
