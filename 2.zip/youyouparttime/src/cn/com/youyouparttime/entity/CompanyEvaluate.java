package cn.com.youyouparttime.entity;

public class CompanyEvaluate {

	private String user;
	private String evaluateContent;
	private String evaluateDetail;
	
	public CompanyEvaluate() {
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getEvaluateContent() {
		return evaluateContent;
	}

	public void setEvaluateContent(String evaluateContent) {
		this.evaluateContent = evaluateContent;
	}

	public String getEvaluateDetail() {
		return evaluateDetail;
	}

	public void setEvaluateDetail(String evaluateDetail) {
		this.evaluateDetail = evaluateDetail;
	}
 
	
}
